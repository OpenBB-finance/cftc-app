"""OpenBB Core App Static."""
